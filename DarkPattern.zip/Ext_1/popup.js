document.getElementById('scrape').addEventListener('click', () => {
  // Query the active tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      // Send a message to the content script to get metadata
      chrome.tabs.sendMessage(tabs[0].id, { action: "getMetadata" }, (response) => {
          if (response) {
              // Store metadata in local storage
              chrome.storage.local.get({ metadataList: [] }, (data) => {
                  const metadataList = data.metadataList;
                  metadataList.push(response);

                  // Update storage with new metadata list
                  chrome.storage.local.set({ metadataList }, () => {
                      alert('Metadata scraped and saved!');
                  });
              });
          } else {
              alert('Failed to retrieve metadata.');
          }
      });
  });
});

document.getElementById('download').addEventListener('click', () => {
  // Retrieve stored metadata from local storage
  chrome.storage.local.get('metadataList', (data) => {
      const metadataList = data.metadataList || [];

      if (metadataList.length === 0) {
          alert('No metadata to download.');
          return;
      }

      // Generate CSV content
      let csvContent = 'data:text/csv;charset=utf-8,URL,Title,Description,Keywords\n';

      metadataList.forEach((metadata) => {
          const row = [
              `"${metadata.url}"`,                  // Wrap URL in quotes if needed
              `"${metadata.title}"`,                // Wrap title in quotes if needed
              `"${metadata.description}"`,          // Wrap description in quotes to prevent comma issues
              `"${metadata.keywords}"`              // Wrap keywords in quotes if needed
          ].join(',');

          csvContent += row + '\n';
      });

      // Create a CSV file and download it
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', 'metadata.csv');
      document.body.appendChild(link); // Required for Firefox
      link.click();
      document.body.removeChild(link); // Clean up after download

      // After download, reset storage automatically
      chrome.storage.local.set({ metadataList: [] }, () => {
          alert('Metadata downloaded and storage reset.');
      });
  });
});

document.getElementById('reset').addEventListener('click', () => {
  // Reset the storage when the reset button is clicked
  chrome.storage.local.set({ metadataList: [] }, () => {
      alert('Storage reset.');
  });
});
