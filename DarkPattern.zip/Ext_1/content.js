// content.js
(function() {
    // Function to collect metadata from the webpage
    const collectMetadata = () => {
        const metadata = {
            url: window.location.href, // Get the website URL
            title: document.querySelector('title')?.innerText || "No title", // Get the title tag content
            description: document.querySelector('meta[name="description"]')?.content || "No description", // Get the description meta tag content
            keywords: document.querySelector('meta[name="keywords"]')?.content || "No keywords" // Get the keywords meta tag content
        };

        return metadata;
    };

    // Listen for messages from popup.js
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "getMetadata") {
            const metadata = collectMetadata();
            sendResponse(metadata);
        }
    });
})();
